import numpy as np
import pandas as pd
from .geokit import getlngandlat, haversine




class HotGridGenerator():
    def __init__(self,gridUnit,searchRadius):
        self.gridUnit=gridUnit
        self.searchRadius=searchRadius
        self.indexList=[]
        self.colList=[]
        self.gridCenter=pd.DataFrame(index=self.indexList, columns=self.colList)
    '''
    设定全局参数
    '''
    def grid_setting(self,df,latcol,lngcol):
        gU=self.gridUnit#网格划分距离
        sR=self.searchRadius#以网格中心搜索poi的搜索半径
        bleed=int(sR/gU)#保留区域范围的出血

        minlng=df[lngcol].min()
        maxlng=df[lngcol].max()
        minlat=df[latcol].min()
        maxlat=df[latcol].max()
        # print('minlng:',minlng)
        # print('maxlng:',maxlng)
        # print('minlat:',minlat)
        # print('maxlat:',maxlat)
        
        midlat=(maxlat+minlat)/2
        midlng=(maxlng+minlng)/2
        dx=haversine(minlat,maxlng,minlat,minlng)
        dy=haversine(minlat,maxlng,maxlat,maxlng)
        # print('x、y方向格点数量')
        # print(dx/gU,dy/gU)#区域大小
        lngL=[]
        latL=[]
        for i in range(bleed,int(dx/gU)-bleed+1):
            dist=i*gU
            tlat,tlng=getlngandlat(minlat,minlng,90,dist)
            lngL.append(tlng)
        for i in range(bleed,int(dy/gU)-bleed+1):
            dist=i*gU
            tlat,tlng=getlngandlat(minlat,minlng,0,dist)
            latL.append(tlat)

        self.indexList=[]
        self.colList=[]
        for k in range(0,len(latL)):
            self.indexList.append(str(k).zfill(3))
        for k in range(0,len(lngL)):
            self.colList.append(str(k).zfill(3))
        self.gridCenter = pd.DataFrame(index=self.indexList, columns=self.colList)
        for i in range(0,len(latL)):
            for j in range(0,len(lngL)):
                self.gridCenter.iloc[i,j]=(latL[i],lngL[j])
        self.gridCenter.sort_index(axis=0,ascending=False).describe()
        # self.gridCenter = gridCenter
        return self.indexList,self.colList,self.gridCenter

    '''
    函数用于对包含地理数据的dataframe进行网格划分，并按网格依次对落在网格内（G200）或网格辐射范围内（R1000）的地理数据计数
    以生成分布热力地图。
    '''
    def gridCounting_basic(self,df0,lat_col,lng_col):
        df_typei=df0
        counting = pd.DataFrame(index=self.indexList, columns=self.colList)
        for i in range(0,len(self.indexList)):
            for j in range(0,len(self.colList)):
                gci=self.gridCenter.iloc[i,j]
                #先取样,减少运算量
                t,maxlng_ij=getlngandlat(gci[0],gci[1],90,self.searchRadius)
                t,minlng_ij=getlngandlat(gci[0],gci[1],90,-self.searchRadius)
                maxlat_ij,t=getlngandlat(gci[0],gci[1],0,self.searchRadius)
                minlat_ij,t=getlngandlat(gci[0],gci[1],0,-self.searchRadius)
                df_typei_ij=df_typei[(df_typei[lat_col]>=minlat_ij)&(df_typei[lat_col]<=maxlat_ij)&(df_typei[lng_col]>=minlng_ij)&(df_typei[lng_col]<=maxlng_ij)]
                #计算sample和gci的距离
                distL=list(map(lambda x,y:haversine(x,y,lat_2=gci[0],lng_2=gci[1]),df_typei_ij[lat_col],df_typei_ij[lng_col]))
                boolL=list(filter(lambda x:x<=self.searchRadius,distL))
    #             print(len(boolL))
                counting.iloc[i,j]=len(boolL)
        return counting.astype(float)

    '''
    函数用于对包含地理数据的dataframe进行网格划分，并按网格依次对落在网格内（G200）或网格辐射范围内（R1000）的地理数据计数;
    与上一个函数不同的是。同时输入类型列名和索引。只对dataframe中特定类型的数据进行计数。
    '''
    def gridCounting_byType(self,df0,lat_col,lng_col,type_col):
        counting_list = []
        for typei in df0[type_col].unique():
            df_typei=df0[df0[type_col]==typei]
        #     print(df_typei)
            counting = self.gridCounting_basic(df_typei,lat_col,lng_col)
            counting_list.append(counting.astype(float))
        return counting_list

    '''
    函数在热力计数的基础上选择一字段进行加权
    '''
    def gridCounting_weight(self,df0,lat_col,lng_col, weight_col):
        df_typei=df0
        counting = pd.DataFrame(index=self.indexList, columns=self.colList)
        for i in range(0,len(self.indexList)):
            for j in range(0,len(self.colList)):
                gci=self.gridCenter.iloc[i,j]
                #先取样,减少运算量
                t,maxlng_ij=getlngandlat(gci[0],gci[1],90,self.searchRadius)
                t,minlng_ij=getlngandlat(gci[0],gci[1],90,-self.searchRadius)
                maxlat_ij,t=getlngandlat(gci[0],gci[1],0,self.searchRadius)
                minlat_ij,t=getlngandlat(gci[0],gci[1],0,-self.searchRadius)
                df_typei_ij=df_typei[(df_typei[lat_col]>=minlat_ij)&(df_typei[lat_col]<=maxlat_ij)&(df_typei[lng_col]>=minlng_ij)&(df_typei[lng_col]<=maxlng_ij)].copy()
                #计算sample和gci的距离
                df_typei_ij.loc[:,'dist']=list(map(lambda x,y:haversine(x,y,lat_2=gci[0],lng_2=gci[1]),df_typei_ij[lat_col],df_typei_ij[lng_col]))
                df_typei_bool=df_typei_ij[df_typei_ij.loc[:,'dist']<=self.searchRadius].copy()
                counting.iloc[i,j]=df_typei_bool.loc[:,weight_col].sum()
    #             print(counting.iloc[i,j])
    #             df_typei_ij.drop(df_typei_ij.index, inplace=True)
    #             print(i,j,df_typei_bool)
        return counting.astype(float)

    def gridCounting_ex(self,df0,lat_col,lng_col,weight_col,type_col):
        counting_list = []
        for typei in df0[type_col].unique():
            df_typei=df0[df0[type_col]==typei]
        #     print(df_typei)
            counting = self.gridCounting_weight(df_typei,lat_col,lng_col,weight_col)
            counting_list.append(counting.astype(float))
        return counting_list
    '''
    该函数用于把分布热力地图dataframe=df0转化为单列数据展开，单列列名colname；
    '''
    @staticmethod
    def hotarray(df0,colname):
        idL=[]
        for i in range(0,df0.shape[0]):
            for j in range(0,df0.shape[1]):
                idL.append('grid'+str(i).zfill(3)+'-'+str(j).zfill(3))
                
        df1=pd.DataFrame(index=idL,columns=[colname])
        c=0
        for i in range(0,df0.shape[0]):
            for j in range(0,df0.shape[1]):
    #             print(c)
                df1.loc[idL[c],colname]=df0.iloc[i,j]
                c+=1
        return df1.astype(float)


# if __name__ == "__main__":
#     geo_df = ''
#     lat_col = 'wgslat'
#     lng_col = 'wgslng'
#     gridUnit=200
#     searchRadius=1000
#     indexList,colList,gridCenter = grid_setting(geo_df,lat_col,lng_col)
