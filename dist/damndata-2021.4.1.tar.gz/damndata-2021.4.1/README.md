# DAMN_Data_Toolkit
### Intro & Installation
* 该第三方包当前分为两部分，一部分用于城市兴趣点数据的获取（damn spider），另一部分用于城市地理点类型数据的热力图显示（damn hotgrid）。后续会继续更新与社交媒体数据相关的获取与处理相关的代码（damn social-media）。
---
### Damn Spider
### Damn Hotgrid
* Geographic Coordinate Calculator
* 
### Examples
* Data Set for Test
---
**Email:** huangzxarchitecture@zju.edu.cn
